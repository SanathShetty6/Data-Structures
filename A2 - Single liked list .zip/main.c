#include "sll.h"

int main()
{
    int option, ndata, gdata, ret, n;

    Slist *head = NULL; // initialize the header to NULL

    while (1)
    {
        // ask user options
        scanf("%d", &option);

        switch (option)
        {
            case 1:
                // Insert at first
                scanf("%d", &ndata);
                if (insert_at_first(&head, ndata) == FAILURE)
                {
                    printf("INFO : Insert first failure\n");
                }
                break;

            case 2:
                // Insert after
                scanf("%d", &gdata);
                scanf("%d", &ndata);
                if ((ret = sl_insert_after(&head, gdata, ndata)) == DATA_NOT_FOUND)
                {
                    printf("INFO : %d is not found at the list\n", gdata);
                }
                else if (ret == LIST_EMPTY)
                {
                    printf("INFO : List is empty\n");
                }
                break;

            case 3:
                // Insert before
                scanf("%d", &gdata);
                scanf("%d", &ndata);
                if ((ret = sl_insert_before(&head, gdata, ndata)) == DATA_NOT_FOUND)
                {
                    printf("INFO : %d is not found at the list\n", gdata);
                }
                else if (ret == LIST_EMPTY)
                {
                    printf("INFO : List is empty\n");
                }
                break;

            case 4:
                // Insert Nth
                scanf("%d", &n);
                scanf("%d", &ndata);
                if ((ret = sl_insert_nth(&head, ndata, n)) == POSITION_NOT_FOUND)
                {
                    printf("INFO : %d Position not found\n", n);
                }
                else if (ret == LIST_EMPTY && n != 1)
                {
                    printf("INFO : List is empty\n");
                }
                else
                {
                    printf("%d is successfully inserted at the position %d\n", ndata, n);
                }
                break;

            case 5:
                // Delete element
                scanf("%d", &ndata);
                if (head == NULL)
                {
                    printf("INFO : List is empty\n");
                }
                else if ((ret = sl_delete_element(&head, ndata)) == DATA_NOT_FOUND)
                {
                    printf("INFO : Element is not found\n");
                }
                else
                {
                    printf("Element Successfully deleted\n");
                }
                break;

            case 6:
                // Print list
                print_list(head);
                break;

            case 7:
                return SUCCESS;

            default:
                printf("Enter proper choice !!\n");
                break;
        }
    }

    return SUCCESS;
}
