#include "queue.h"

int enqueue(Queue_t **front, Queue_t **rear, int data)
{
    // Create the new node
    Queue_t *new = malloc(sizeof(Queue_t));
    if (new == NULL)
    {
        return FAILURE; // Memory allocation failed
    }

    // Initialize the new node
    new->data = data;
    new->link = NULL;

    if (*rear == NULL)
    {
        // If the queue is empty, both front and rear will point to the new node
        *front = new;
        *rear = new;
        new->link = new; // Circular link
    }
    else
    {
        // Insert new node at the end of the queue and update the rear
        (*rear)->link = new;
        new->link = *front; // Maintain the circular nature
        *rear = new;
    }

    return SUCCESS;
}
