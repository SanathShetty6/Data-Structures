#include "sll.h"

//remove duplicate data's from list
int remove_duplicates( Slist **head )
{
    /* check for list empty or not */
    if(*head == NULL)
    {
	return FAILURE;
    }


    /* if only one node present */
    if(((*head) -> link) == NULL)
    {
	return SUCCESS;
    }


    /* create local reference pointer */
    Slist *temp = *head;    //1st element
    Slist *t2;       //pointer for looping through the list
    Slist *duplicate;       //stores duplicate element node address


    /* loop to compare all elements against duplicacy */
    while (temp != NULL && temp -> link != NULL)
    {
	/* updating t2 pointer */
	t2 = temp;

	/* comparing one element with rest of the elements */
	while(t2 -> link != NULL)
	{
	    if(temp-> data == (t2 -> link) -> data)      //if duplicate element found
	    {
		duplicate = t2 -> link;      //storing the duplicate element address to duplicate pointer

		t2 -> link = (t2 -> link) -> link;    //updating the link of temp_iter pointer

		free(duplicate);        //deallocating the memory
	    }
	    else        //if duplicate element not found
	    {
		t2 = t2 -> link;      //updating the temp_iter
	    }
	}

	/* updating the temp after each complete iteration through the list */
	temp = temp -> link;
    }

    return SUCCESS;
}
