#include "stack.h"

int Pop(Stack_t **top)
{
	

}