#include "stack.h"

int Push(Stack_t **top, data_t data)
{

}