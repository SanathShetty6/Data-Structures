#include "stack.h"

int Peek(Stack_t **top)
{

}