#include "stack.h"



/* Function for Poping the element */
int Pop(Stack_t *s, int element)
{
    if (s->top == -1) // function call to is_stack_empty()
    {
        return FAILURE;
    }
    element = s->stack[s->top];

    (s->top)--; // decrementing the top

    return SUCCESS;
}
