#include "stack.h"

/* Function for display the top of the element in Stack */
int Peek(Stack_t *s, int element)
{
    if (s->top == -1) // function call to is_stack_empty()
    {
        return FAILURE;
    }

    element = s->stack[s->top]; // returning the top element
    return element;
}
