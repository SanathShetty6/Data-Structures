#include "sll.h"
int sl_delete_last(Slist **head)
{
    // Check if the list is empty
    if (*head == NULL)
    {
        return FAILURE; // Return failure if list is empty
    }
    // Check if only one node is present
    if (((*head)->link) == NULL)
    {
        *head = NULL; // Set head to NULL as the only node is deleted
        return SUCCESS; // Return success
    }

    // Create local reference pointers
    Slist *temp = *head;
    Slist *prev;

    // Traverse through the list till last node
    while (temp->link != NULL)
    {
        prev = temp;
        temp = temp->link;
    }

    // Check if the last node is reached
    if (temp->link == NULL)
    {
        prev->link = NULL; // Update the link of second last node to NULL
        free(temp); // Deallocate the memory of the last node
    }
}
