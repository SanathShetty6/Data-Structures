#include "sll.h"
int sl_delete_first(Slist **head)
{
    // Check if the list is empty
    if(*head == NULL)
    {
        return FAILURE; // Return failure if list is empty
    }
    else
    {
        Slist *temp = *head;
        *head = temp->link; // Update head to the next node
        free(temp); // Free the memory of the deleted node
        return SUCCESS; // Return success
    }
}
