#include "sll.h"

int insert_at_last(Slist **head, data_t data)
{
    //create a node
    Slist *new = malloc(sizeof(Slist));

    //error check
    if(new == NULL)
    {
        return FAILURE;
    }

    //Update data and link field
    new->data = data;
    new->link = NULL;

    //list is empty or not
    if(*head == NULL)
    {
        *head = new;
        return SUCCESS;
    }

    //non empty
    //Create a local reference pointer
    Slist *temp = *head;
    //Traverse through through list to reach last node 
    while(temp->link != NULL)
    {
        temp = temp->link;
    }

    //establish new link between last node and new node

    temp->link = new;
    return SUCCESS;

}