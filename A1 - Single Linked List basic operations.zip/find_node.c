#include "sll.h"
int find_node(Slist *head, data_t key)
{
    int count = 0;

    if (head == NULL)
    {
        return FAILURE;
    }

    // create local reference pointer
    Slist *temp = head;

    // traversing through the list
    while (temp != NULL)
    {
        if (temp->data == key) // if data matched
        {
            // Increment count here because we found the key
            count++;
            return count; // Return the position of the key
        }
        else
        {
            temp = temp->link; // move to the next node
            count++;           // incrementing the position
        }
    }

    return FAILURE; // Key not found
}
