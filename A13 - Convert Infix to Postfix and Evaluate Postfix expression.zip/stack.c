#include "main.h"

/* function to check the priority of the operators */
int priority(char opr)
{
    if (opr == '*' || opr == '/') {
        return 3;
    }
    if (opr == '+' || opr == '-') {
        return 2;
    }
    return 0;
}

/* function to push to stack */
void push(Stack_t *stk, int data)
{
    ++(stk -> top);
    stk -> stack[stk -> top] = data;
}

/* function to pop from stack */
void pop(Stack_t *stk)
{
    if (stk -> top != -1)
	--(stk -> top);
}

/* function to peek the topmost element of stack */
int peek(Stack_t *stk)
{
    if (stk -> top != -1)
    {
	return stk -> stack[stk -> top];
    }
    return -1;
}

