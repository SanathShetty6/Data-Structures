/*
NAME: SANATH SHETTY P
DATE: 20/05/2024
DESCRIPTION: Convert Infix to Postfix and Evaluate Postfix expression
SAMPLE EXECUTION:
Infix to Postfix:
Case-1	
Input	2 * 3 – 3 + 8 / 4 / (1 + 1)
Output	2 3 * 3 – 8 4 / 1 1 + / +
Case-2	Multiple digit numbers
Input	2 * 30 – 3 + 8 / 4 / (10 + 1)
Output	2, 30, *, 3, –, 8, 4, /, 10, 1, +, / ,+

Postfix evaluation:
Case-1	Single digit numbers
Input	2 3 * 3 – 8 4 / 1 1 + / +
Output	4
Case-2	Multiple digit numbers
Input	2, 30, *, 3, –, 8, 4, /, 10, 1, +, / ,+
Output	57.181
*/

#include "main.h"
#include <string.h>

int main()
{
    char Infix_exp[50], Postfix_exp[50], ch;
    int choice, result;
    Stack_t stk;
    stk.top = -1;

    printf("Enter the Infix expression : ");
    scanf("%s", Infix_exp);

    Infix_Postfix_conversion(Infix_exp, Postfix_exp, &stk);
    printf("PostFix expression : %s\n", Postfix_exp);
    stk.top = -1;
    result = Postfix_Eval(Postfix_exp, &stk);
    printf("\nResult : %d\n", result);
    return 0;
}
