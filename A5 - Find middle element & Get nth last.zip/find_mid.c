#include "sll.h"
/* Function to get the middle of the linked list*/
int find_mid(Slist *head, int *mid) 
{ 
    //check the link is empty or not
    if(head == NULL)
    {
        return LIST_EMPTY;
    }
    //Create a local reference pointer
    Slist *fast = head;
    Slist *Slow = head;

    //Traverse till end of list
    while(fast != NULL && fast->link != NULL )
    {
        fast = (fast ->link)->link; //To move 2 node faster
        Slow = Slow->link; //To move 1 node
    }

    *mid = Slow->data; //Storing mid data
    return SUCCESS;
} 



