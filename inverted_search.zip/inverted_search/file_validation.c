#include "inverted_search.h"

void file_validation_n_file_list(Flist **f_head, char *argv[])
{
	int i = 1, empty;
	while (argv[i] != NULL)
	{
		empty = isFileEmpty(argv[i]);

		if (empty == FILE_NOTAVAILABLE)
		{
			printf("File : %s is not available\n", argv[i]);
			printf("Hence we are not adding that file\n");
			i++;
			continue;
		}
		else if (empty == FILE_EMPTY)
		{
			printf("File : %s is not having any content \n", argv[i]);
			printf("Hence we are not adding that file\n");
			i++;
			continue;
		}
		else
		{
			// add files to file LL
			int ret_val = to_create_list_of_files(f_head, argv[i]);
			if (ret_val == SUCCESS)
			{
				printf("Successfull : Inserting the file : %s into file LL\n", argv[i]);
			}
			else if (ret_val == REPEATATION)
			{
				printf("This file name : %s is repeated. Hence we are not adding that file\n", argv[i]);
			}
			else
			{
				printf("Failure\n");
			}
			i++;
			continue;
		}
	}
}

// fun is used to check file availability and also for file content check
int isFileEmpty(char *filename)
{
	FILE *fptr = fopen(filename, "r");
	if (fptr == NULL)
	{
		if (errno == ENOENT)
		{
			return FILE_NOTAVAILABLE;
		}
	}

	fseek(fptr, 0, SEEK_END);
	if (ftell(fptr) == 0)
	{
		return FILE_EMPTY;
	}
}

int to_create_list_of_files(Flist **f_head, char *name)
{
	//.......TODO......
	// check for duplicancy
	// insert_last
	Flist *new = malloc(sizeof(Flist));

	// error check for memory allocation
	if (new == NULL)
	{
		return FAILURE;
	}

	// updating the node parts
	strcpy(new->file_name, name);
	new->link = NULL;

	// check for list empty or not
	if (*f_head == NULL)
	{
		*f_head = new;
		return SUCCESS;
	}

	// create local reference pointer
	Flist *temp = *f_head;
	Flist *temp_prev;

	if (temp->link == NULL)
	{
		// checking if duplicate file name present
		if (strcmp(temp->file_name, name) == 0)
		{
			return REPEATATION;
		}
	}

	// traversing through the list till last node
	while (temp != NULL)
	{
		// checking if duplicate file name present
		if (strcmp(temp->file_name, name) == 0)
		{
			return REPEATATION;
		}

		temp_prev = temp;
		temp = temp->link;
	}

	// when last node is reached, establishing the link between the last node and the new node
	temp_prev->link = new;

	return SUCCESS;
}
