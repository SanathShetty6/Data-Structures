#include "inverted_search.h"

void update_database(Wlist *head[], Flist **f_head)
{
    // prompt the user for new file to update the database

    char file_name[FNAME_SIZE];
    printf("Enter the new file \n");
    scanf("%s", file_name);

    // validate the file
    //......TODO........
    int empty;
    empty = isFileEmpty(file_name);

    if (empty == FILE_NOTAVAILABLE)
    {
        printf("File : %s is not available\n", file_name);
    }
    else if (empty == FILE_EMPTY)
    {
        printf("File : %s is not having any contents in it\n", file_name);
    }

    int ret_val;
    ret_val = to_create_list_of_files(f_head, file_name);
    if (ret_val == SUCCESS)
    {
        Flist *temp = *f_head;
        while (temp)
        {
            if (!strcmp(temp->file_name, file_name))
            {
                create_database(*f_head, head);
            }
            temp = (temp->link);
        }
    }
}
