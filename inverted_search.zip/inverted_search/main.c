/*
NAME: SANATH SHETTY .P
DATE:04/06/2024

PROJECT NAME: INVERTED SEARCH

DESCRIPTION:
An inverted index is an index data structure storing a mapping from content, such as words or 
numbers, to its locations in a database file, or in a document or a set of documents. The purpose of
an inverted index is to allow fast full text searches, at the cost of increased processing when a
document is added to the database. The inverted file may be the database file itself, rather than its
index. It is the most popular data structure used in document retrieval systems, used on a large
scale for example in search engines.

The purpose of storing an index is to optimize speed and performance in
finding relevant documents for a search query. Without an index, the search
engine would scan every document in the corpus, which would require
considerable time and computing power.

*/
#include "inverted_search.h"

int main(int argc, char *argv[])
{
    system("clear");

    char option;
    int choice;

    Wlist *head[27] = {NULL};

    // validate CLA
    if (argc <= 1)
    {
        printf("Enter the valid no. arguments\n");
        printf("./Slist.exe file1.txt file2.txt.......\n");
        return 0;
    }

    // create the file linked list

    // declare a head pointer
    Flist *f_head = NULL;

    // validate the files
    file_validation_n_file_list(&f_head, argv);

    if (f_head == NULL)
    {
        printf("No file are available in the file LL\n");
        printf("Hence the process is terminated\n");
        return 0;
    }
    /* prompt the user for choice */
    //.......TODO.......
    do
    {
        printf("\nSelect your choice among following options:\n");
        printf(" 1. Create DATABASE\n 2. Display Database\n 3. Update DATABASE\n 4. Search\n 5. Save Database\n");

        printf("\nEnter your choice: ");
        scanf("%d", &choice);
        printf("\n");

        switch (choice)
        {
        case 1:

            // Create Database
            create_database(f_head, head);
            {
                while (f_head != NULL)
                {
                    printf("Successful: Creation of database for file : %s\n", f_head->file_name);
                    f_head = f_head->link;
                }
            }
            break;

        case 2:

            // Display Database
            display_database(head);
            break;

        case 3:

            // Update Database
            update_database(head, &f_head);
            break;

        case 4:

            // Search in Databae
            {
                char word[WORD_SIZE];

                // promt the user to enter the search word
                printf("Enter the word to search: ");
                scanf("%s", word);

                search(head[tolower(word[0]) % 97], word);
            }
            break;

        case 5:

            // Save Database
            save_database(head);
            break;

        default:

            printf("Invalid option\n");
        }

        /* check for continue */
        printf("\nDo you want to continue (y/n): ");
        scanf("\n%c", &option);

    } while (option == 'y' || option == 'Y');

    return 0;
}
