#include "inverted_search.h"

void save_database(Wlist *head[])
{
    // prompt the user for file

    int i;
    char file_name[FNAME_SIZE];

    printf("Enter the file name to save the database\n");
    scanf("%s", file_name);

    // open file
    FILE *fptr = fopen(file_name, "w");

    for (i = 0; i < 27; i++)
    {
        if (head[i] != NULL)
        {
            write_databasefile(head[i], fptr);
        }
    }

    printf("Database saved\n");
}

void write_databasefile(Wlist *head, FILE *databasefile)
{
    //............TODO.........
    // #[index]  [word] :  [file_count]   :   file_name   :  [word_count]
    int flag;
    // transverse through the Wlist
    while (head != NULL)
    {
        flag = 0;
        fprintf(databasefile, "%5d  %10s    %10d    File/s:  ", tolower(head->word[0]) % 97, head->word, head->file_count);

        Ltable *Thead = head->Tlink;

        // traverse through the Ltable
        while (Thead)
        {
            if (flag == 1)
            {
                fprintf(databasefile, "%44c", ' ');
            }
            fprintf(databasefile, "%15s    %10d\n", Thead->file_name, Thead->word_count);
            Thead = Thead->table_link;
            flag = 1;
        }
        fprintf(databasefile, "\n\n");
        head = head->link;
    }
}
