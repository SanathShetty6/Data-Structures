/*
NAME: SANATH SHETTY P
DATE: 21/05/2024
DESCRIPTION: Convert Infix to Prefix and evaluation Prefix expression
SAMPLE EXECUTION:
1. Infix – Prefix converstion
Case-1	Single digit numbers
Input	2 * 3 – 3 + 8 / 4 / (1 + 1)
Output	+ – * 2 3 3 / / 8 4 + 1 1
Case-2	Multiple digit numbers
Input	2 * 30 – 3 + 8 / 4 / (10 + 1)
Output	+, -, *, 2, 30, 3, /, /, 8, 4, +, 10, 1
2. Prefix Evaluation
Case-1	Single digit numbers
Input	+ – * 2 3 3 / / 8 4 + 1 1
Output	4
Case-2	Multiple digit numbers
Input	+, -, *, 2, 30, 3, /, /, 8, 4, +, 10, 1
Output	57.181

*/

#include "main.h"

void strrev(char *string)
{/* function to reverse the string */
    int i = 0;
    int strlen = 0;
    int index = 0;
    int len;
    int limit;
    char swap;

    len = my_strlen(string) - 1;
    limit = len / 2;

    /* reversing the string */
    for (int j = 0; j <= limit; j++)
    {
        swap = string[index];
        string[index] = string[len];
        string[len] = swap;

        index++;
        len--;
    }
}

int main()
{
    char Infix_exp[50], Prefix_exp[50], ch;
    int choice, result;
    Stack_t stk;
    stk.top = -1;

    printf("Enter the Infix expression : ");
    scanf("%s", Infix_exp);

    strrev(Infix_exp);
    Infix_Prefix_conversion(Infix_exp, Prefix_exp, &stk);
    strrev(Prefix_exp);
    printf("PreFix expression : %s\n", Prefix_exp);

    stk.top = -1;

    strrev(Prefix_exp);
    result = Prefix_Eval(Prefix_exp, &stk);
    printf("\nResult : %d\n", result);
    return 0;
}
